import { useState } from 'react'
import ListBlog from './components/ListBlog'
import AddBlog from './components/AddBlog'

function App() {

  return (
<>
       <AddBlog />
       <ListBlog />
    </>
  )
}

export default App
