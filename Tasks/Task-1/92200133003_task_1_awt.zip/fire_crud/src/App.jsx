import { useState } from 'react'
import AddBook from './components/addBooks'
import BookLists from './components/ListBooks'

function App() {

  return (
    <>
        {/* <AddBook/> */}
        <BookLists />
    </>
  )
}

export default App
