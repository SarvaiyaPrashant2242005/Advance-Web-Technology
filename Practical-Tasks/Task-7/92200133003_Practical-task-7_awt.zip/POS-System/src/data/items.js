const items = [
    { id: 1, name: "Pen", price: 10 },
    { id: 2, name: "Notebook", price: 50 },
    { id: 3, name: "Pencil", price: 5 },
    { id: 4, name: "Eraser", price: 3 },
    { id: 5, name: "Scale", price: 15 }
  ];
  
  export default items;
  