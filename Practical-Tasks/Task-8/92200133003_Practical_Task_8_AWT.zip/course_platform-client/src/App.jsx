import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import SearchBar from './components/SearchBar';
import CourseCard from './components/CourseCard';
import EnrolledCourses from './pages/EnrolledCourses';

const dummyCourses = [
  { id: 1, title: "React for Beginners", description: "Learn the basics of React including components, props, and state.", instructor: "Shamsagazaarzoo Alam" },
  { id: 2, title: "Advanced JavaScript", description: "Deep dive into JavaScript concepts like closures, prototypes, and async programming.", instructor: "Shamsagazaarzoo Alam" },
  { id: 3, title: "Python for Data Science", description: "Use Python for data analysis, visualization, and machine learning.", instructor: "Nishith Kotak" },
  { id: 4, title: "UI/UX Design Fundamentals", description: "Understand the principles of good user interface and user experience design.", instructor: "Herry" },
  { id: 5, title: "Full Stack Web Development", description: "Build complete web apps with React, Node.js, Express, and MongoDB.", instructor: "Shamsagazaarzoo Alam" },
  { id: 6, title: "Android App Development", description: "Create native Android apps using Kotlin and Android Studio.", instructor: "Raj Patel" },
  { id: 7, title: "Data Structures & Algorithms", description: "Master common data structures and algorithms to crack coding interviews.", instructor: "Anjali Mehra" },
  { id: 8, title: "Machine Learning A-Z", description: "Learn machine learning with practical examples using Python and Scikit-Learn.", instructor: "Mr. CD Parmar" },
  { id: 9, title: "Ethical Hacking for Beginners", description: "Get started with cybersecurity and ethical hacking fundamentals.", instructor: "Hitesh Choudhary" },
  { id: 10, title: "SQL & Database Management", description: "Learn SQL from scratch and manage relational databases efficiently.", instructor: "Harikesh Chauhan" },
  { id: 11, title: "Cloud Computing with AWS", description: "Explore AWS cloud services, EC2, S3, Lambda, and more.", instructor: "Arjav Bawarva" },
  { id: 12, title: "DevOps Essentials", description: "Understand CI/CD pipelines, Docker, Kubernetes, and GitOps.", instructor: "Neha Singh" }
];

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [enrolled, setEnrolled] = useState([]);

  const filteredCourses = dummyCourses.filter(course =>
    course.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleEnroll = (course) => {
    if (!enrolled.some(c => c.id === course.id)) {
      setEnrolled([...enrolled, course]);
      alert(`You have enrolled in "${course.title}"`);
    } else {
      alert("Already enrolled!");
    }
  };

  return (
    <Router>
      <div className="App">
        <nav className="navbar">
          <Link to="/">Home</Link>
          <Link to="/enrolled">Enrolled Courses</Link>
        </nav>

        <Routes>
          <Route path="/" element={
            <>
              <h1>Course Platform</h1>
              <div className="search-container">
                <SearchBar value={searchTerm} onChange={setSearchTerm} />
              </div>
              <h2>All Courses</h2>
              <div className="course-list">
                {filteredCourses.length > 0 ? (
                  filteredCourses.map(course => (
                    <CourseCard key={course.id} course={course} onEnroll={handleEnroll} />
                  ))
                ) : (
                  <p>No courses found.</p>
                )}
              </div>
            </>
          } />
          <Route path="/enrolled" element={<EnrolledCourses enrolled={enrolled} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
