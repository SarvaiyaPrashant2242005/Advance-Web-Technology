import { useState } from 'react'
import StudentResultManagement from './components/StudentResultManagement'


function App() {


  return (
    <>
      <StudentResultManagement />
    </>
  )
}

export default App
