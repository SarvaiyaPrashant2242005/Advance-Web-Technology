import { useState } from 'react'
import EcommerceApp from './EcommerceApp'

function App() {

  return (
    <>
      <EcommerceApp />
    </>
  )
}

export default App
