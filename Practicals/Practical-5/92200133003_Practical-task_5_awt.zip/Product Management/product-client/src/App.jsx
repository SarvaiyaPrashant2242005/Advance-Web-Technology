import React from "react";
import ProductPage from "./ProductPage";

function App() {
  return (
    <div className="App">
      <h1>Product Management</h1>
      <ProductPage />
    </div>
  );
}

export default App;
