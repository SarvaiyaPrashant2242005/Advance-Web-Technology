// components/PaymentDetails.js
import React, { useState, useEffect } from 'react';

const PaymentDetails = ({ patientId, previousBalance = 0, onSave }) => {
  const [medicineFee, setMedicineFee] = useState('');
  const [testFee, setTestFee] = useState('');
  const [currentPayment, setCurrentPayment] = useState('');
  const [remarks, setRemarks] = useState('');
  const [remaining, setRemaining] = useState(0);

  useEffect(() => {
    const total = 
      Number(previousBalance) + 
      Number(medicineFee || 0) + 
      Number(testFee || 0) - 
      Number(currentPayment || 0);
    setRemaining(total);
  }, [previousBalance, medicineFee, testFee, currentPayment]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      patientId,
      previousBalance,
      medicineFee: Number(medicineFee),
      testFee: Number(testFee),
      currentPayment: Number(currentPayment),
      remaining,
      remarks
    };
    onSave(data);
  };

  return (
    <div className="card p-4 mt-4 shadow-sm">
      <h4>Patient ID: {patientId}</h4>
      <h5>Receive Payment</h5>
      <form onSubmit={handleSubmit}>
        <div className="row mb-3">
          <div className="col-md-4">
            <label>Previous Balance</label>
            <input type="number" className="form-control" value={previousBalance}  />
          </div>
          <div className="col-md-4">
            <label>Medicine Fee</label>
            <input type="number" className="form-control" value={medicineFee} onChange={(e) => setMedicineFee(e.target.value)} />
          </div>
          <div className="col-md-4">
            <label>Extra Test Fee</label>
            <input type="number" className="form-control" value={testFee} onChange={(e) => setTestFee(e.target.value)} placeholder="e.g. 50" />
          </div>
        </div>

        <div className="row mb-3">
          <div className="col-md-6">
            <label>Current Payment</label>
            <input type="number" className="form-control" value={currentPayment} onChange={(e) => setCurrentPayment(e.target.value)} />
          </div>
          <div className="col-md-6">
            <label>Remaining Amount</label>
            <input type="number" className="form-control" value={remaining} readOnly />
          </div>
        </div>

        <div className="mb-3">
          <label>Remarks</label>
          <textarea className="form-control" rows="2" value={remarks} onChange={(e) => setRemarks(e.target.value)}></textarea>
        </div>

        <div className="text-end">
          <button type="submit" className="btn btn-primary">Save Payment</button>
        </div>
      </form>
    </div>
  );
};

export default PaymentDetails;
