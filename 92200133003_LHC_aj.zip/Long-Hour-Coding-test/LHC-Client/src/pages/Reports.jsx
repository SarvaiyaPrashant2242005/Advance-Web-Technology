import React from 'react'
import Navbar from '../components/Navbar'

const Reports = () => {
  return (
    <div>
      <Navbar />
    </div>
  )
}

export default Reports
